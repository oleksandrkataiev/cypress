export function clickOnMaleGender() {
  cy.contains('Male').click();
  cy.wait(2000);
}
