// First question
export function clickOnExpertOption() {
  cy.get('[data-value="expert"]').click();
}

// Second question
export function clickOnGotItButton() {
  cy.get('[data-key="whatisfasting"] .m-next').click();
}

// Third question
export function clickOnEveningOption() {
  cy.get('[data-value="evening"]').click();
}

// Forth question
export function clickOnBreakfastSkipOption() {
  cy.get('[data-key="breakfast"] [data-value="Skip"]').click();
}

// Fifth question
export function clickOnLunchSkipOption() {
  cy.get('[data-key="lunch"] [data-value="Skip"]').click();
}

// Sixth question
export function clickOnDinnerSkipOption() {
  cy.get('[data-key="dinner"] [data-value="Skip"]').click();
}

// Seventh question
export function clickOnPreparationBothOption() {
  cy.get('[data-key="preparation"] [data-value="both"]').click();
}

// Eighth question
export function clickOnWeekendDifficultyEasyOption() {
  cy.get('[data-value="easy"]').click();
}

// Ninth question
export function clickOnActivityLevelNewbieOption() {
  cy.get('[data-value="newbie"]').click();
}

// Tenth question
export function clickOnWorkHoursMixedOption() {
  cy.get('[data-value="mixed"]').click();
}

// Eleventh question
export function clickOnJobTypePhysicallyOption() {
  cy.get('[data-value="physically"]').click();
}

// Twelveth question
export function clickOnMotivationTryOption() {
  cy.get('[data-value="try"]').click();
}

// Thirteenth question
export function clickOnMetricButton() {
  cy.contains('Metric').click();
}

export function inputAge(age) {
  cy.get('[name="age"]').type(age);
}

export function inputCentimeters(centimeters) {
  cy.get('[name="centimeters"]').type(centimeters);
}

export function inputWeight(weight) {
  cy.get('[name="weight"]').type(weight);
}

export function inputDesiredWeight(weight) {
  cy.get('[name="desired_weight"]').type(weight);
}

export function clickOnNextButton() {
  cy.contains('Next').click();
  cy.wait(5000);
}
