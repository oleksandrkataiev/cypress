import * as home_page from './pages/home_page.js';
import * as questionnaire_page from './pages/questionnaire_page.js';

describe('Testing of the positive reaction of the form with physical data if real information is entered', function() {

    it('ValidFormFunctionalityTestCest', function() {
        cy.visit('https://dofasting.com/')

        // Choose Male oprion
        home_page.clickOnMaleGender()
        cy.url().should('include', '/questionnaire?gender=male')

        // Answer all questions
        questionnaire_page.clickOnExpertOption()
        questionnaire_page.clickOnGotItButton()
        questionnaire_page.clickOnEveningOption()
        questionnaire_page.clickOnBreakfastSkipOption()
        questionnaire_page.clickOnLunchSkipOption()
        questionnaire_page.clickOnDinnerSkipOption()
        questionnaire_page.clickOnPreparationBothOption()
        questionnaire_page.clickOnWeekendDifficultyEasyOption()
        questionnaire_page.clickOnActivityLevelNewbieOption()
        questionnaire_page.clickOnWorkHoursMixedOption()
        questionnaire_page.clickOnJobTypePhysicallyOption()
        questionnaire_page.clickOnMotivationTryOption()
        cy.url().should('include', '/questionnaire?gender=male#que13')

        // Choose Metric and input valid data
        questionnaire_page.clickOnMetricButton()
        questionnaire_page.inputAge(38)
        questionnaire_page.inputCentimeters(177)
        questionnaire_page.inputWeight(98)
        questionnaire_page.inputDesiredWeight(82)
        questionnaire_page.clickOnNextButton()
        cy.url().should('include', '/results-app')
    })
})
